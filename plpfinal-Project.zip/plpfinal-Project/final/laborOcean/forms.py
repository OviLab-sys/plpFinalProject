from dataclasses import fields
from pyexpat import model
from django import forms
from django.contrib.auth.models import User
from .models import Customer,Appointment


class UserForm(forms.ModelForm):
     password = forms.CharField(widget=forms.PasswordInput())
     
     
     class Meta:
          model = User
          fields = ['username', 'password']
          
class CustomerForm(forms.ModelForm):
     class Meta:
          model = Customer
          fields = ['phone'] 
          
class BookingForm(forms.ModelForm):
     class Meta:
          model = Appointment
          fields = '__all__'