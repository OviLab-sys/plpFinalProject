from email import message
from django.urls import reverse
from django.shortcuts import render, redirect, HttpResponseRedirect, HttpResponse
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate,logout
from .models import Appointment, Services
from .forms import CustomerForm, UserForm, BookingForm
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm


def index(request):
     myservices = Services.objects.all().values()
     context = {
          'myservices':myservices
     }
     return render(request, 'home.html', context)

def register_user(request):
     registered = False
     if request.method=='POST':
          customerform = CustomerForm(request.POST)
          userform = UserForm(request.POST)
          if userform.is_valid() and customerform.is_valid():
               user = userform.save()
               user.set_password(user.password)
               user.save()
               customerform.save()
               registered = True
               user = authenticate(request, username=user.username, password=request.POST['password'])
               if user is not None:
                    login(request, user)
                    return redirect('index')
          
          else:
               print(userform.errors,customerform.errors )
     else:
          userform=UserForm()
          customerform=CustomerForm()
     return render(request,'register.html', {'userform':userform,'customerform':customerform,'registered':registered}) 
 
 

     
def login_user(request):
     if request.method =='POST':
         username = request.POST['username']
         password = request.POST['password']
         user = authenticate(request, username= username, password = password)
         if user is not None:
              login(request, user)
              messages.info(request, 'you are now logged in a.')
              return redirect('index')
         else:
              messages.error(request, 'invalid username or password.')
     form = AuthenticationForm()
     return render(request, 'login.html', {'login_form':form})
     
         
                   


@login_required     
def logout_user(request):
     logout(request)
     return HttpResponseRedirect(reverse('index')) 

def booking(request):
     form = BookingForm()
     if request.method =='POST':
          form = BookingForm(request.POST)
          if form.is_valid():
               form.save()
               return redirect('index')
     context ={'form':form}
     return render(request, 'booking.html', context)

def editBooking(request,pk):
     booking= Appointment.objects.get(id=pk)
     form=BookingForm(instance=booking)
     if request.method == 'POST':
          form = BookingForm(request.Post, instance=booking)
          if form.is_valid_path():
               form.save()
               return redirect('projects')
     context={'form':form}
     return render(request,'project-form.html', context)