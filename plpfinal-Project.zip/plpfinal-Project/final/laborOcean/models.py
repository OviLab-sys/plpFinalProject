from math import fabs
from unicodedata import category
from django.db import models
import datetime
from django.contrib.auth.models import User

class Category(models.Model):
     name =models.CharField(max_length=50)
     
     @staticmethod
     def get_all_categories():
          return Category.objects.all()
     
     def __str__(self):
          return self.name

class Customer(models.Model):
     user = models.OneToOneField(User,on_delete=models.CASCADE, primary_key=True)
     phone = models.CharField(max_length=50)
     
     def __str__(self):
          return self.user.username
     
     def register(self):
          self.save()
          
     @staticmethod
     def get_customer_by_email(email):
          try:
               return Customer.objects.get(email=email)
          except:
               return False
          
     def isExists(self):
          if Customer.objects.filter(email=self.email):
               return True
          else:
               return False
          
     
class Services(models.Model):
     name = models.CharField(max_length=100)
     price = models.CharField(max_length=50)
     category = models.ForeignKey(Category, on_delete=models.CASCADE)
     description = models.CharField(max_length=500, default = '', blank=True, null = True)
     image = models.ImageField(blank =True, null=True, upload_to ='images/')
     
     def __str__(self):
          return self.name
     
     @staticmethod
     def get_service_by_id(ids):
          return Services.objects.filter(id__in = ids)
     
     @staticmethod
     def get_all_services():
          return Services.objects.all()
     
     @staticmethod
     def get_all_services_by_categoryid(category_id):
          if category_id:
               return Services.objects.filter(category=category_id)
          else:
               return Services.get_all_services()
     @property
     def imageURL(self):
          img = ''
          try:
               img = self.image.URL
          except:
               img=''
               return img
          
     
class Appointment(models.Model):
     name = models.CharField(max_length=100, null=False, blank=False)
     service =models.ForeignKey(Services,on_delete=models.CASCADE)
     description = models.CharField(max_length=1000)
     address = models.CharField(max_length=100,null=False, blank=False )
     phone = models.CharField(max_length=20, null=False, blank=False)